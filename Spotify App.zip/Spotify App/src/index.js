import React from "react";
import ReactDOM from "react-dom";
import "./index.css";
import img1 from "./images/library_icon.png";
import img2 from "./images/backward_icon.png";
import img3 from "./images/forward_icon.png";
import img4 from "./images/card1img.jpeg";
import img5 from "./images/card2img.jpeg";
import img6 from "./images/card3img.jpeg";
import img7 from "./images/card4img.jpeg";
import img8 from "./images/card1img.jpeg";
import img10 from "./images/card5img.jpeg";
import img11 from "./images/card6img.jpeg";
import img12 from "./images/card1img.jpeg";
import img13 from "./images/player_icon1.png";
import img14 from "./images/player_icon2.png";
import img15 from "./images/player_icon3.png";
import img16 from "./images/player_icon4.png";
import img17 from "./images/player_icon5.png";

const img_15 = {
  opacity: "1",
  height: "2rem",
};

ReactDOM.render(
  <>
    <head>
      <meta charset="UTF-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      <title>Spotify - Web Player</title>
      <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"
        integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA=="
        crossorigin="anonymous"
        referrerpolicy="no-referrer"
      />
      <link rel="icon" href="./assets/logo.png" />
      <link rel="preconnect" href="https://fonts.googleapis.com" />
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
      <link
        href="https://fonts.googleapis.com/css2?family=Indie+Flower&display=swap"
        rel="stylesheet"
      />
      <link rel="stylesheet" href="style.css" />
    </head>
    <body>
      <div class="main">
        <div class="sidebar">
          <div class="nav">
            <div class="nav-option">
              <i class="fa-solid fa-house"></i>
              <a href="www.google.com">Home</a>
            </div>
            <div class="nav-option">
              <i class="fa-solid fa-magnifying-glass"></i>
              <a href="www.google.com">Search</a>
            </div>
          </div>
          <div class="library">
            <div class="options">
              <div class="lib-option nav-option">
                <img src={img1} alt="" />
                <a href="www.google.com">Library</a>
              </div>
              <div class="icons">
                <i class="fa-solid fa-plus"></i>
                <i class="fa-solid fa-arrow-right"></i>
              </div>
            </div>
            <div class="lib-box">
              <div class="box">
                <p class="box-p1">Create your first playlist</p>
                <p class="box-p2">It easy we'll help you</p>
                <button class="badge">Create playlist</button>
              </div>
              <div class="box">
                <p class="box-p1">Let's find some podcasts to follow</p>
                <p class="box-p2">We'll keep you updated on new episodes</p>
                <button class="badge">browse podcasts</button>
              </div>
            </div>
          </div>
        </div>
        <div class="main_content">
          <div class="sticky-nav">
            <div class="sticky-nav-icons">
              <img src={img2} alt="" />
              <img src={img3} class="hide" alt="" />
            </div>

            <div class="sticky-nav-options">
              <button class="badge nav-item hide">Explore Premium</button>
              <button class="badge nav-item dark-badge">
                <i class="fa-solid fa-circle-down Space"></i>Install App
              </button>
              <i class="fa-solid fa-user nav-item"></i>
            </div>
          </div>
          <h2>Recently Played</h2>
          <div class="cards-container">
            <div class="card">
              <img src={img4} class="class-img" alt="" />
              <p class="card-title">Top 50 - Global</p>
              <p class="card-info">
                Your daily updates of the most played tracks...
              </p>
            </div>
          </div>

          <h2>Trending now near you</h2>
          <div class="cards-container">
            <div class="card">
              <img src={img5} class="class-img" alt="" />
              <p class="card-title">Top 50 - Global</p>
              <p class="card-info">
                Your daily updates of the most played tracks...
              </p>
            </div>

            <div class="card">
              <img src={img6} class="class-img" alt="" />
              <p class="card-title">Top 50 - Global</p>
              <p class="card-info">
                Your daily updates of the most played tracks...
              </p>
            </div>

            <div class="card">
              <img src={img7} class="class-img" alt="" />
              <p class="card-title">Top 50 - Global</p>
              <p class="card-info">
                Your daily updates of the most played tracks...
              </p>
            </div>

            <div class="card">
              <img src={img8} class="class-img" alt="" />
              <p class="card-title">Top 50 - Global</p>
              <p class="card-info">
                Your daily updates of the most played tracks...
              </p>
            </div>
          </div>

          <h2>Featured Charts</h2>
          <div class="cards-container">
            <div class="card">
              <img src={img10} class="class-img" alt="" />
              <p class="card-title">Top 50 - Global</p>
              <p class="card-info">
                Your daily updates of the most played tracks...
              </p>
            </div>

            <div class="card">
              <img src={img11} class="class-img" alt="" />
              <p class="card-title">Top Songs - India</p>
              <p class="card-info">
                Your daily updates of the most played tracks...
              </p>
            </div>

            <div class="card">
              <img src={img12} class="class-img" alt="" />
              <p class="card-title">Top 50 - Global</p>
              <p class="card-info">
                Your daily updates of the most played tracks...
              </p>
            </div>
          </div>
          <div class="footer">
            <div class="line"></div>
          </div>
        </div>
        <div class="music-player">
          <div class="album"></div>
          <div class="player">
            <div class="player-controls">
              <img src={img13} class="player-control-icon" alt="" />
              <img src={img14} class="player-control-icon" alt="" />
              <img
                src={img15}
                class="player-control-icon"
                style={img_15}
                alt=""
              />
              <img src={img16} class="player-control-icon" alt="" />
              <img src={img17} class="player-control-icon" alt="" />
            </div>
            <div class="playback-bar">
              <span class="current-time">00.00</span>
              <input
                type="range"
                min="0"
                max="100"
                step="1"
                class="progress-bar"
              />
              <span class="total-time">3.34</span>
            </div>
          </div>
          <div class="control"></div>
        </div>
      </div>
    </body>
  </>,
  document.getElementById("root")
);
